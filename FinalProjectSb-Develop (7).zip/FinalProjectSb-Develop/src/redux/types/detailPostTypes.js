export const DETAIL_POST = 'DETAIL_POST'
