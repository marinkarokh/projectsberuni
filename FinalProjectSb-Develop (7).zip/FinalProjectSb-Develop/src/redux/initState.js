const initState = () => {



	return {
		posts: [],
		search: '',
		person: {},
		likes: [],
		comments: [],
		comment: [],
	}
}

export default initState